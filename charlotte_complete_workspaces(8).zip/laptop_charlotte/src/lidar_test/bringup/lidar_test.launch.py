# lidar_test.launch.py
#
# Runs on the LAPTOP. Opens RViz2 on ROS domain 4 with rviz/lidar_test.rviz,
# showing the LaserScan published by the Raspberry Pi on /ldlidar_node/scan.
#
#   ros2 launch lidar_test lidar_test.launch.py

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


ROS_DOMAIN_ID = '4'


def generate_launch_description():
    default_rviz = os.path.join(
        get_package_share_directory('lidar_test'), 'rviz', 'lidar_test.rviz')

    rviz_config = LaunchConfiguration('rviz_config')

    return LaunchDescription([
        SetEnvironmentVariable('ROS_DOMAIN_ID', ROS_DOMAIN_ID),
        SetEnvironmentVariable('ROS_AUTOMATIC_DISCOVERY_RANGE', 'SUBNET'),

        DeclareLaunchArgument(
            'rviz_config', default_value=default_rviz,
            description='Full path to the RViz2 config file'),

        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['-d', rviz_config],
        ),
    ])
