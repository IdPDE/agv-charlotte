^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ffw_swerve_drive_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.15 (2025-12-09)
-------------------
* Updated for new realtime_tools::RealtimePublisher API
* Contributors: Woojin Wie

1.1.14 (2025-10-14)
-------------------
* None

1.1.13 (2025-10-14)
-------------------
* None

1.1.12 (2025-09-17)
-------------------
* None

1.1.11 (2025-08-13)
-------------------
* Fix velocity limit variable
* Contributors: Woojin Wie

1.1.10 (2025-07-22)
-------------------
* None

1.1.9 (2025-07-18)
------------------
* None

1.1.8 (2025-07-14)
------------------
* None

1.1.7 (2025-07-11)
------------------
* None

1.1.6 (2025-07-07)
------------------
* Fix header file name for tf2
* Contributors: Woojin Wie

1.1.5 (2025-06-30)
------------------
* None

1.1.4 (2025-06-27)
------------------
* None

1.1.3 (2025-06-26)
------------------
* None

1.1.2 (2025-06-26)
------------------
* None

1.1.1 (2025-06-26)
------------------
* None

1.1.0 (2025-06-16)
------------------
* Add swerve drive controller package for ffw_sg2_rev1
* Contributors: Geonhee Lee
