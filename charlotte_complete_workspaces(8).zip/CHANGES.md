# What is new / changed compared to your original workspaces

NEW = added, CHANGED = modified, everything else is your original file untouched.

## pi_charlotte/src
- NEW     charlotte_hardware/                 ros2_control plugin for the SPARK MAXes over CAN + spark_can_probe.py
- NEW     charlotte_pi_bringup/               robot_pi.launch.py (controller_manager + lidar), controller_manager.yaml, setup_can.sh
- NEW     ffw_swerve_drive_controller/        identical copy of the laptop package (the Pi's controller_manager loads it)
- CHANGED lidar_pi/bringup/lidar_pi.launch.py new args scan_topic / frame_id (defaults = old behaviour)

## laptop_charlotte/src/swerve_robot
- CHANGED description/charlotte_swerve_bot.urdf  sim_mode arg: Gazebo or real <ros2_control> block
- CHANGED bringup/robot_v2.launch.py             passes sim_mode to xacro, new args map:= and slam:=
- NEW     config/charlotte_slam_toolbox.yaml     mapping config for slam:=true
- CHANGED package.xml                            exec_depends slam_toolbox, lifecycle_msgs, teleop_twist_keyboard

Unchanged but used on the real robot: config/charlotte_nav2_params.yaml, charlotte_ekf.yaml, nav_modes.xml,
dock_locations.yaml, robots_map.yaml/map.pgm, charlotte_swerve_drive_controllers_params.yaml, scan_mask_swerve_drive.yaml.

The build/, install/ and log/ folders were left out: run `colcon build` in both workspaces.
Your colleague's heartbeat.py / motor_control.py / hardware_agv.cpp are replaced by charlotte_hardware.

## Update after bring-up on the Pi (firmware 26.1.5)
- charlotte_hardware: status frames accepted in API class 6 and 46; heartbeat + zero output kept alive
  while configured/inactive (SPARKs only report with a heartbeat); universal heartbeat off by default.
- spark_can_probe.py: same fixes; monitor/calibrate send heartbeat + zero output themselves.
- charlotte_swerve_bot.urdf: measured direction / abs_sign / offsets, send_universal_heartbeat false.
- BRINGUP_REAL_ROBOT.md: CAN HAT overlay, auto-start of can0, wiring, measured values, open issue motor 32.

## Update: controller parameters on the Pi
- charlotte_pi_bringup/config/controller_manager.yaml now also holds the swerve_drive_controller
  parameters (copy of the sim file with use_sim_time false). Keep both copies in sync.
- robot_v2.launch.py: in real mode the swerve controller spawner runs WITHOUT --param-file
  (a laptop /tmp path is useless on the Pi). Simulation unchanged.
- ldrobot-lidar-ros2/ldlidar_component/CMakeLists.txt: also install the SDK library
  (install(TARGETS ${PROJECT_NAME} ldlidar ...)); without it libldlidar.so is missing at runtime.

## Update: bench limits (lab power supply)
- URDF: steer_max_duty 0.25 (was 0.6), drive_max_duty 0.3 (was 0.8). Restore on battery.
- Pi controller_manager.yaml: steering_angular_velocity_limit 4.0 rad/s (was 100; sim file keeps 100).

## Update: lidar publishes with a remapped topic
- ldrobot-lidar-ros2/ldlidar_component/component/src/ldlidar_component.cpp: the driver only publishes
  when it has subscribers, but counted them on the original name /ldlidar_node/scan (count_subscribers
  ignores remaps). Now uses _scanPub->get_subscription_count(), so /charlotte/scan_raw works.
