#!/usr/bin/env bash
# Bring up the CAN HAT interface for the SPARK MAXes (1 Mbit/s, FRC standard).
# Run once after every boot (or use the systemd-networkd config from the README
# to make it permanent).
set -e
IFACE=${1:-can0}
sudo ip link set "$IFACE" down 2>/dev/null || true
sudo ip link set "$IFACE" up type can bitrate 1000000 restart-ms 100
sudo ip link set "$IFACE" txqueuelen 1000
ip -details -statistics link show "$IFACE"
