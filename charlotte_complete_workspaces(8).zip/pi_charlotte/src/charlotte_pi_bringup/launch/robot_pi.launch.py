# robot_pi.launch.py
#
# Runs on the RASPBERRY PI of the real robot. Starts:
#   1. ros2_control controller_manager (/charlotte/controller_manager) with the
#      charlotte_hardware/SparkMaxSwerveSystem plugin talking to the SPARK MAXes
#      on can0. The URDF is taken from /charlotte/robot_description, which is
#      published by robot_state_publisher on the LAPTOP (robot_v2.launch.py
#      use_sim_time:=false). The controllers themselves are spawned from the
#      laptop as well, so the controller parameters exist only once.
#   2. The LD19 lidar, publishing /charlotte/scan_raw in frame lidar_link
#      (what the laptop's scan_mask_node expects - same as in simulation).
#
#   ros2 launch charlotte_pi_bringup robot_pi.launch.py
#
# Start order: Pi first (it waits for the URDF), then the laptop.
# Before the first run: setup_can.sh (or the systemd-networkd config in the README).

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, LogInfo
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory('charlotte_pi_bringup')
    lidar_share = get_package_share_directory('lidar_pi')

    namespace = 'charlotte'
    use_lidar = LaunchConfiguration('use_lidar')

    controller_manager = Node(
        package='controller_manager',
        executable='ros2_control_node',
        namespace=namespace,
        output='screen',
        parameters=[os.path.join(pkg_share, 'config', 'controller_manager.yaml')],
        remappings=[
            # URDF comes from robot_state_publisher on the laptop
            ('~/robot_description', f'/{namespace}/robot_description'),
        ],
    )

    lidar = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(lidar_share, 'bringup', 'lidar_pi.launch.py')),
        launch_arguments={
            'scan_topic': f'/{namespace}/scan_raw',
            'frame_id': 'lidar_link',
        }.items(),
        condition=IfCondition(use_lidar),
    )

    return LaunchDescription([
        DeclareLaunchArgument('use_lidar', default_value='true',
                              description='Also start the LD19 lidar driver'),
        LogInfo(msg=f'[robot_pi] ROS_DOMAIN_ID={os.environ.get("ROS_DOMAIN_ID", "NOT SET")} - '
                    'waiting for /charlotte/robot_description from the laptop...'),
        controller_manager,
        lidar,
    ])
