// spark_max_can.cpp - see header for protocol notes.

#include "charlotte_hardware/spark_max_can.hpp"

#include <linux/can/raw.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#include <cerrno>
#include <cstring>

namespace charlotte_hardware
{

namespace
{
float read_float_le(const uint8_t * data)
{
  float value;
  std::memcpy(&value, data, sizeof(float));  // Pi (ARM) and x86 are little-endian
  return value;
}

void write_float_le(uint8_t * data, float value)
{
  std::memcpy(data, &value, sizeof(float));
}
}  // namespace

SparkMaxCanBus::SparkMaxCanBus(StatusLayout layout)
: layout_(layout) {}

SparkMaxCanBus::~SparkMaxCanBus()
{
  close();
}

bool SparkMaxCanBus::open(const std::string & interface_name, std::string & error)
{
  close();

  sock_ = ::socket(PF_CAN, SOCK_RAW, CAN_RAW);
  if (sock_ < 0) {
    error = std::string("socket(PF_CAN) failed: ") + std::strerror(errno);
    return false;
  }

  struct ifreq ifr {};
  std::strncpy(ifr.ifr_name, interface_name.c_str(), IFNAMSIZ - 1);
  if (::ioctl(sock_, SIOCGIFINDEX, &ifr) < 0) {
    error = "CAN interface '" + interface_name + "' not found (" + std::strerror(errno) +
      "). Is it up? Run: sudo ip link set " + interface_name + " up type can bitrate 1000000";
    ::close(sock_);
    sock_ = -1;
    return false;
  }

  // Only receive REV motor-controller frames (device type 2, manufacturer 5).
  struct can_filter filter {};
  filter.can_id = kRevMotorControllerBase | CAN_EFF_FLAG;
  filter.can_mask = 0x1FFF0000u | CAN_EFF_FLAG | CAN_RTR_FLAG;
  ::setsockopt(sock_, SOL_CAN_RAW, CAN_RAW_FILTER, &filter, sizeof(filter));

  // Don't receive our own transmitted frames back.
  int loopback = 0;
  ::setsockopt(sock_, SOL_CAN_RAW, CAN_RAW_RECV_OWN_MSGS, &loopback, sizeof(loopback));

  // RX timeout so the RX thread can exit cleanly.
  struct timeval tv {};
  tv.tv_sec = 0;
  tv.tv_usec = 100000;
  ::setsockopt(sock_, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

  struct sockaddr_can addr {};
  addr.can_family = AF_CAN;
  addr.can_ifindex = ifr.ifr_ifindex;
  if (::bind(sock_, reinterpret_cast<struct sockaddr *>(&addr), sizeof(addr)) < 0) {
    error = std::string("bind() on CAN socket failed: ") + std::strerror(errno);
    ::close(sock_);
    sock_ = -1;
    return false;
  }

  running_ = true;
  rx_thread_ = std::thread(&SparkMaxCanBus::rx_loop, this);
  return true;
}

void SparkMaxCanBus::close()
{
  running_ = false;
  if (rx_thread_.joinable()) {
    rx_thread_.join();
  }
  if (sock_ >= 0) {
    ::close(sock_);
    sock_ = -1;
  }
}

SparkFeedback SparkMaxCanBus::feedback(uint8_t device_id) const
{
  std::lock_guard<std::mutex> lock(mutex_);
  return feedback_[device_id & 0x3F];
}

bool SparkMaxCanBus::send_frame(uint32_t arbitration_id, const uint8_t * data, uint8_t len)
{
  if (sock_ < 0) {
    return false;
  }
  struct can_frame frame {};
  frame.can_id = (arbitration_id & CAN_EFF_MASK) | CAN_EFF_FLAG;
  frame.can_dlc = len;
  std::memcpy(frame.data, data, len);
  // MSG_DONTWAIT: never block the real-time loop when the TX queue is full
  // (e.g. motor controllers unpowered -> no ACKs on the bus).
  const ssize_t n = ::send(sock_, &frame, sizeof(frame), MSG_DONTWAIT);
  if (n != static_cast<ssize_t>(sizeof(frame))) {
    tx_errors_++;
    return false;
  }
  return true;
}

bool SparkMaxCanBus::send_setpoint(uint32_t api_id, uint8_t device_id, float value)
{
  // Setpoint frame: float32 setpoint, then (unused here) arbitrary feed-forward
  // and PID slot -> zeros.
  uint8_t data[8] = {0};
  write_float_le(data, value);
  return send_frame(kRevMotorControllerBase | api_id | (device_id & 0x3F), data, 8);
}

bool SparkMaxCanBus::send_duty_cycle(uint8_t device_id, float duty)
{
  return send_setpoint(kApiDutyCycleSetpoint, device_id, duty);
}

bool SparkMaxCanBus::send_velocity(uint8_t device_id, float velocity)
{
  return send_setpoint(kApiVelocitySetpoint, device_id, velocity);
}

bool SparkMaxCanBus::send_position(uint8_t device_id, float position)
{
  return send_setpoint(kApiPositionSetpoint, device_id, position);
}

bool SparkMaxCanBus::send_rev_heartbeat()
{
  // Every bit set = all device ids 0..63 enabled (same as the colleague's heartbeat.py).
  const uint8_t data[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
  return send_frame(kRevHeartbeatId, data, 8);
}

bool SparkMaxCanBus::send_universal_heartbeat()
{
  // FRC universal heartbeat bitfield (little-endian packed struct):
  //   bit 25 = enabled, bit 28 = system watchdog  ->  byte 3 = 0b0001'0010
  uint8_t data[8] = {0};
  data[3] = (1u << 1) | (1u << 4);
  return send_frame(kUniversalHeartbeatId, data, 8);
}

void SparkMaxCanBus::rx_loop()
{
  struct can_frame frame {};
  while (running_) {
    const ssize_t n = ::read(sock_, &frame, sizeof(frame));
    if (n == static_cast<ssize_t>(sizeof(frame))) {
      handle_frame(frame);
    }
    // n < 0 with EAGAIN/EWOULDBLOCK -> timeout, loop to check running_
  }
}

void SparkMaxCanBus::handle_frame(const struct can_frame & frame)
{
  if (!(frame.can_id & CAN_EFF_FLAG) || (frame.can_id & CAN_RTR_FLAG)) {
    return;
  }
  const uint32_t id = frame.can_id & CAN_EFF_MASK;
  if ((id & 0x1FFF0000u) != kRevMotorControllerBase) {
    return;
  }
  const uint8_t device = id & 0x3F;
  const uint32_t api_class = (id >> 10) & 0x3F;
  const uint32_t api_index = (id >> 6) & 0xF;
  if (api_class != kStatusClassLegacy && api_class != kStatusClassNew) {
    return;  // not a periodic status frame
  }
  const auto now = SteadyClock::now();
  rx_frames_++;

  std::lock_guard<std::mutex> lock(mutex_);
  SparkFeedback & fb = feedback_[device];
  fb.frames_received++;

  if (layout_ == StatusLayout::kFirmware2025) {
    if (api_index == kStatusIndex2 && frame.can_dlc >= 8) {
      fb.motor_velocity = read_float_le(&frame.data[0]);
      fb.motor_position = read_float_le(&frame.data[4]);
      fb.has_velocity = fb.has_position = true;
      fb.last_velocity = fb.last_position = now;
    } else if (api_index == kStatusIndex5 && frame.can_dlc >= 8) {
      fb.abs_velocity = read_float_le(&frame.data[0]);
      fb.abs_position = read_float_le(&frame.data[4]);
      fb.has_abs = true;
      fb.last_abs = now;
    }
  } else {  // 2024 layout
    if (api_index == kStatusIndex1 && frame.can_dlc >= 4) {
      fb.motor_velocity = read_float_le(&frame.data[0]);
      fb.has_velocity = true;
      fb.last_velocity = now;
    } else if (api_index == kStatusIndex2 && frame.can_dlc >= 4) {
      fb.motor_position = read_float_le(&frame.data[0]);
      fb.has_position = true;
      fb.last_position = now;
    } else if (api_index == kStatusIndex5 && frame.can_dlc >= 4) {
      fb.abs_position = read_float_le(&frame.data[0]);
      fb.has_abs = true;
      fb.last_abs = now;
    }
  }
}

}  // namespace charlotte_hardware
