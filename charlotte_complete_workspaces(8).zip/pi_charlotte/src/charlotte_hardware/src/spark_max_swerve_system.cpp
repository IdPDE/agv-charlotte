// spark_max_swerve_system.cpp
//
// Replaces the colleague's hardware_agv.cpp / heartbeat.py / motor_control.py:
//   * heartbeat is sent from a thread inside this plugin. While active it is
//     only sent if write() has been called recently: if the controller_manager
//     hangs or crashes, the heartbeat stops and the SPARK MAXes disable
//     themselves (~100 ms). While configured-but-inactive it is sent together
//     with zero duty-cycle commands, because the SPARKs (firmware 25+/26) only
//     send status frames while they receive a heartbeat.
//   * steering uses a PD loop (software mode, default) or the SPARK's own
//     position PID (onboard mode) instead of bang-bang duty cycle.
//   * steering angle comes from the NEO 550 relative encoder (Status 2, fast),
//     seeded at activation from the MAXSwerve absolute encoder (Status 5).

#include "charlotte_hardware/spark_max_swerve_system.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <unordered_map>

#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "pluginlib/class_list_macros.hpp"

namespace charlotte_hardware
{

namespace
{
constexpr double kTwoPi = 2.0 * M_PI;

double wrap_pi(double a)
{
  return std::remainder(a, kTwoPi);  // [-pi, pi]
}

std::string get_param(
  const std::unordered_map<std::string, std::string> & params,
  const std::string & key, const std::string & default_value)
{
  const auto it = params.find(key);
  return it == params.end() ? default_value : it->second;
}

double get_double(
  const std::unordered_map<std::string, std::string> & params,
  const std::string & key, double default_value)
{
  const auto it = params.find(key);
  if (it == params.end()) {
    return default_value;
  }
  try {
    return std::stod(it->second);
  } catch (const std::exception &) {
    throw std::runtime_error("parameter '" + key + "' is not a number: '" + it->second + "'");
  }
}

bool get_bool(
  const std::unordered_map<std::string, std::string> & params,
  const std::string & key, bool default_value)
{
  const auto it = params.find(key);
  if (it == params.end()) {
    return default_value;
  }
  std::string v = it->second;
  std::transform(v.begin(), v.end(), v.begin(), ::tolower);
  return v == "true" || v == "1" || v == "yes";
}

int64_t steady_now_ns()
{
  return std::chrono::duration_cast<std::chrono::nanoseconds>(
    SteadyClock::now().time_since_epoch()).count();
}

double age_s(SteadyClock::time_point t)
{
  return std::chrono::duration<double>(SteadyClock::now() - t).count();
}
}  // namespace

SparkMaxSwerveSystem::~SparkMaxSwerveSystem()
{
  active_ = false;
  stop_heartbeat_thread();
  if (bus_) {
    stop_all_motors();
    bus_->close();
  }
}

// --------------------------------------------------------------------------
// on_init: parse parameters from the URDF <ros2_control> block
// --------------------------------------------------------------------------
hardware_interface::CallbackReturn SparkMaxSwerveSystem::on_init(
  const hardware_interface::HardwareInfo & info)
{
  if (hardware_interface::SystemInterface::on_init(info) !=
    hardware_interface::CallbackReturn::SUCCESS)
  {
    return hardware_interface::CallbackReturn::ERROR;
  }

  try {
    const auto & hw = info_.hardware_parameters;
    can_interface_ = get_param(hw, "can_interface", "can0");

    const std::string layout = get_param(hw, "firmware_layout", "2025");
    if (layout == "2025") {
      layout_ = StatusLayout::kFirmware2025;
    } else if (layout == "2024") {
      layout_ = StatusLayout::kFirmware2024;
    } else {
      RCLCPP_FATAL(logger_, "firmware_layout must be '2024' or '2025', got '%s'", layout.c_str());
      return hardware_interface::CallbackReturn::ERROR;
    }

    send_rev_heartbeat_ = get_bool(hw, "send_rev_heartbeat", true);
    // The FRC universal heartbeat (roboRIO) keeps firmware 26.1.5 SPARKs DISABLED
    // (measured on Charlotte): only the REV heartbeat enables them. Off by default.
    send_universal_heartbeat_ = get_bool(hw, "send_universal_heartbeat", false);
    heartbeat_period_ms_ = static_cast<int>(get_double(hw, "heartbeat_period_ms", 20.0));
    command_watchdog_s_ = get_double(hw, "command_watchdog_s", 0.15);
    feedback_timeout_s_ = get_double(hw, "feedback_timeout_s", 0.3);
    startup_timeout_s_ = get_double(hw, "startup_timeout_s", 5.0);
    require_absolute_encoder_ = get_bool(hw, "require_absolute_encoder", true);

    steer_gear_ratio_ = get_double(hw, "steer_gear_ratio", 9424.0 / 203.0);
    drive_gear_ratio_ = get_double(hw, "drive_gear_ratio", 5.5);
    abs_units_per_rev_ = get_double(hw, "abs_units_per_rev", 1.0);
    motor_units_per_rev_ = get_double(hw, "motor_units_per_rev", 1.0);
    motor_units_per_rpm_ = get_double(hw, "motor_units_per_rpm", 1.0);

    const std::string steer_mode = get_param(hw, "steer_control_mode", "software");
    if (steer_mode == "software") {
      steer_mode_ = SteerControlMode::kSoftware;
    } else if (steer_mode == "onboard_position") {
      steer_mode_ = SteerControlMode::kOnboardPosition;
    } else {
      RCLCPP_FATAL(logger_, "steer_control_mode must be 'software' or 'onboard_position'");
      return hardware_interface::CallbackReturn::ERROR;
    }
    steer_kp_ = get_double(hw, "steer_kp", 1.0);
    steer_kd_ = get_double(hw, "steer_kd", 0.02);
    steer_ks_ = get_double(hw, "steer_ks", 0.02);
    steer_max_duty_ = get_double(hw, "steer_max_duty", 0.6);
    steer_deadband_rad_ = get_double(hw, "steer_deadband_rad", 0.015);

    const std::string drive_mode = get_param(hw, "drive_control_mode", "duty_cycle");
    if (drive_mode == "duty_cycle") {
      drive_mode_ = DriveControlMode::kDutyCycle;
    } else if (drive_mode == "velocity") {
      drive_mode_ = DriveControlMode::kVelocity;
    } else {
      RCLCPP_FATAL(logger_, "drive_control_mode must be 'duty_cycle' or 'velocity'");
      return hardware_interface::CallbackReturn::ERROR;
    }
    drive_free_speed_rpm_ = get_double(hw, "drive_free_speed_rpm", 5676.0);
    drive_kff_ = get_double(hw, "drive_kff", 0.0);
    if (drive_kff_ <= 0.0) {
      // duty = wheel_speed / wheel_free_speed
      const double wheel_free_rad_s = drive_free_speed_rpm_ / drive_gear_ratio_ * kTwoPi / 60.0;
      drive_kff_ = 1.0 / wheel_free_rad_s;
    }
    drive_kp_ = get_double(hw, "drive_kp", 0.002);
    drive_max_duty_ = get_double(hw, "drive_max_duty", 0.8);

    // ---- joints ----
    joints_.clear();
    for (const auto & j : info_.joints) {
      if (j.command_interfaces.size() != 1) {
        RCLCPP_FATAL(logger_, "Joint '%s' must have exactly 1 command interface", j.name.c_str());
        return hardware_interface::CallbackReturn::ERROR;
      }
      SparkJoint sj;
      sj.name = j.name;
      const std::string & cmd_if = j.command_interfaces[0].name;
      if (cmd_if == hardware_interface::HW_IF_POSITION) {
        sj.is_steer = true;
      } else if (cmd_if == hardware_interface::HW_IF_VELOCITY) {
        sj.is_steer = false;
      } else {
        RCLCPP_FATAL(
          logger_, "Joint '%s': command interface must be 'position' (steering) or "
          "'velocity' (wheel), got '%s'", j.name.c_str(), cmd_if.c_str());
        return hardware_interface::CallbackReturn::ERROR;
      }
      if (j.parameters.find("can_id") == j.parameters.end()) {
        RCLCPP_FATAL(logger_, "Joint '%s' is missing <param name=\"can_id\">", j.name.c_str());
        return hardware_interface::CallbackReturn::ERROR;
      }
      const int can_id = static_cast<int>(get_double(j.parameters, "can_id", 0));
      if (can_id < 1 || can_id > 62) {
        RCLCPP_FATAL(logger_, "Joint '%s': can_id must be 1..62", j.name.c_str());
        return hardware_interface::CallbackReturn::ERROR;
      }
      sj.can_id = static_cast<uint8_t>(can_id);
      sj.direction = get_double(j.parameters, "direction", 1.0) < 0.0 ? -1.0 : 1.0;
      sj.offset = get_double(j.parameters, "offset", 0.0);
      sj.abs_sign = get_double(j.parameters, "abs_sign", 1.0) < 0.0 ? -1.0 : 1.0;
      joints_.push_back(sj);
    }

    for (size_t a = 0; a < joints_.size(); ++a) {
      for (size_t b = a + 1; b < joints_.size(); ++b) {
        if (joints_[a].can_id == joints_[b].can_id) {
          RCLCPP_FATAL(
            logger_, "Joints '%s' and '%s' share CAN id %d", joints_[a].name.c_str(),
            joints_[b].name.c_str(), joints_[a].can_id);
          return hardware_interface::CallbackReturn::ERROR;
        }
      }
    }
  } catch (const std::exception & e) {
    RCLCPP_FATAL(logger_, "Parameter error: %s", e.what());
    return hardware_interface::CallbackReturn::ERROR;
  }

  std::ostringstream ss;
  for (const auto & j : joints_) {
    ss << "\n  " << j.name << ": " << (j.is_steer ? "steer" : "drive") << " can_id=" <<
      static_cast<int>(j.can_id) << " dir=" << j.direction;
    if (j.is_steer) {
      ss << " offset=" << j.offset << " abs_sign=" << j.abs_sign;
    }
  }
  RCLCPP_INFO(
    logger_, "SparkMaxSwerveSystem: %zu joints on %s (layout %s, steer=%s, drive=%s):%s",
    joints_.size(), can_interface_.c_str(),
    layout_ == StatusLayout::kFirmware2025 ? "2025" : "2024",
    steer_mode_ == SteerControlMode::kSoftware ? "software PD" : "onboard position",
    drive_mode_ == DriveControlMode::kDutyCycle ? "duty cycle" : "onboard velocity",
    ss.str().c_str());

  return hardware_interface::CallbackReturn::SUCCESS;
}

std::vector<hardware_interface::StateInterface> SparkMaxSwerveSystem::export_state_interfaces()
{
  std::vector<hardware_interface::StateInterface> s;
  for (auto & j : joints_) {
    s.emplace_back(j.name, hardware_interface::HW_IF_POSITION, &j.position);
    s.emplace_back(j.name, hardware_interface::HW_IF_VELOCITY, &j.velocity);
  }
  return s;
}

std::vector<hardware_interface::CommandInterface>
SparkMaxSwerveSystem::export_command_interfaces()
{
  std::vector<hardware_interface::CommandInterface> c;
  for (auto & j : joints_) {
    c.emplace_back(
      j.name, j.is_steer ? hardware_interface::HW_IF_POSITION : hardware_interface::HW_IF_VELOCITY,
      &j.command);
  }
  return c;
}

// --------------------------------------------------------------------------
// Lifecycle
// --------------------------------------------------------------------------
hardware_interface::CallbackReturn SparkMaxSwerveSystem::on_configure(
  const rclcpp_lifecycle::State &)
{
  bus_ = std::make_unique<SparkMaxCanBus>(layout_);
  std::string error;
  if (!bus_->open(can_interface_, error)) {
    RCLCPP_FATAL(logger_, "%s", error.c_str());
    bus_.reset();
    return hardware_interface::CallbackReturn::ERROR;
  }

  heartbeat_running_ = true;
  heartbeat_thread_ = std::thread(&SparkMaxSwerveSystem::heartbeat_loop, this);

  // Status frames are sent by the SPARKs even when disabled, so we can already
  // check that every device is talking to us.
  if (!wait_for_feedback(startup_timeout_s_)) {
    stop_heartbeat_thread();
    bus_->close();
    bus_.reset();
    return hardware_interface::CallbackReturn::ERROR;
  }

  for (auto & j : joints_) {
    const auto fb = bus_->feedback(j.can_id);
    update_joint_state(j, fb);  // initial (unseeded) values
  }
  RCLCPP_INFO(logger_, "Configured: all %zu SPARK MAXes report feedback", joints_.size());
  return hardware_interface::CallbackReturn::SUCCESS;
}

bool SparkMaxSwerveSystem::wait_for_feedback(double timeout_s)
{
  const auto start = SteadyClock::now();
  while (age_s(start) < timeout_s) {
    bool all_ok = true;
    for (const auto & j : joints_) {
      const auto fb = bus_->feedback(j.can_id);
      if (!fb.has_position || !fb.has_velocity) {
        all_ok = false;
      }
      if (j.is_steer && require_absolute_encoder_ && !fb.has_abs) {
        all_ok = false;
      }
    }
    if (all_ok) {
      return true;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(20));
  }

  std::ostringstream ss;
  for (const auto & j : joints_) {
    const auto fb = bus_->feedback(j.can_id);
    ss << "\n  " << j.name << " (id " << static_cast<int>(j.can_id) << "): frames=" <<
      fb.frames_received << " position=" << (fb.has_position ? "ok" : "MISSING") <<
      " velocity=" << (fb.has_velocity ? "ok" : "MISSING");
    if (j.is_steer) {
      ss << " abs_encoder=" << (fb.has_abs ? "ok" : "MISSING");
    }
  }
  RCLCPP_FATAL(
    logger_,
    "No (complete) feedback from SPARK MAXes after %.1f s on %s (total RX frames: %lu):%s\n"
    "Checks: CAN wiring/termination, 'candump %s', CAN ids, firmware_layout (2024/2025), "
    "run charlotte_hardware/spark_can_probe.py monitor.",
    timeout_s, can_interface_.c_str(), static_cast<unsigned long>(bus_->rx_frames()),
    ss.str().c_str(), can_interface_.c_str());
  return false;
}

void SparkMaxSwerveSystem::seed_steering(SparkJoint & j, const SparkFeedback & fb, bool use_abs)
{
  j.seed_motor_rot = fb.motor_position;
  if (use_abs) {
    const double abs_rad = j.abs_sign * fb.abs_position / abs_units_per_rev_ * kTwoPi;
    j.seed_angle = wrap_pi(abs_rad - j.offset);
  } else {
    j.seed_angle = 0.0;
  }
}

hardware_interface::CallbackReturn SparkMaxSwerveSystem::on_activate(
  const rclcpp_lifecycle::State &)
{
  if (!bus_) {
    return hardware_interface::CallbackReturn::ERROR;
  }

  // Give the absolute encoder frame (default 200 ms period on older firmware)
  // a moment to arrive with a fresh value.
  std::this_thread::sleep_for(std::chrono::milliseconds(300));

  for (auto & j : joints_) {
    const auto fb = bus_->feedback(j.can_id);
    if (j.is_steer) {
      const bool abs_ok = fb.has_abs && age_s(fb.last_abs) < 1.0;
      if (!abs_ok) {
        if (require_absolute_encoder_) {
          RCLCPP_FATAL(
            logger_, "%s: no fresh absolute-encoder frame (Status 5) from id %d",
            j.name.c_str(), j.can_id);
          return hardware_interface::CallbackReturn::ERROR;
        }
        RCLCPP_WARN(
          logger_, "%s: no absolute encoder, assuming the module is pointing straight "
          "ahead right now!", j.name.c_str());
      }
      seed_steering(j, fb, abs_ok);
      update_joint_state(j, fb);
      j.command = j.position;  // hold current angle
      RCLCPP_INFO(
        logger_, "%s: steering angle at start = %.3f rad (%.1f deg)", j.name.c_str(),
        j.position, j.position * 180.0 / M_PI);
    } else {
      update_joint_state(j, fb);
      j.command = 0.0;
    }
  }

  stale_ = false;
  last_write_ns_ = steady_now_ns();
  active_ = true;
  RCLCPP_INFO(logger_, "Activated: heartbeat running, motors enabled");
  return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn SparkMaxSwerveSystem::on_deactivate(
  const rclcpp_lifecycle::State &)
{
  active_ = false;
  stop_all_motors();
  RCLCPP_INFO(logger_, "Deactivated: motors stopped, heartbeat paused");
  return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn SparkMaxSwerveSystem::on_cleanup(
  const rclcpp_lifecycle::State &)
{
  active_ = false;
  stop_heartbeat_thread();
  if (bus_) {
    stop_all_motors();
    bus_->close();
    bus_.reset();
  }
  return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn SparkMaxSwerveSystem::on_shutdown(
  const rclcpp_lifecycle::State & state)
{
  return on_cleanup(state);
}

hardware_interface::CallbackReturn SparkMaxSwerveSystem::on_error(
  const rclcpp_lifecycle::State & state)
{
  RCLCPP_ERROR(logger_, "on_error: stopping all motors");
  on_cleanup(state);
  return hardware_interface::CallbackReturn::SUCCESS;
}

void SparkMaxSwerveSystem::stop_all_motors()
{
  if (!bus_) {
    return;
  }
  for (int k = 0; k < 3; ++k) {
    for (const auto & j : joints_) {
      bus_->send_duty_cycle(j.can_id, 0.0f);
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(5));
  }
}

void SparkMaxSwerveSystem::stop_heartbeat_thread()
{
  heartbeat_running_ = false;
  if (heartbeat_thread_.joinable()) {
    heartbeat_thread_.join();
  }
}

void SparkMaxSwerveSystem::heartbeat_loop()
{
  const auto period = std::chrono::milliseconds(std::max(5, heartbeat_period_ms_));
  auto next = SteadyClock::now();
  bool warned = false;
  while (heartbeat_running_) {
    next += period;
    const double since_write = (steady_now_ns() - last_write_ns_.load()) * 1e-9;
    if (!active_) {
      // Configured but not active (also during on_configure/on_activate):
      // the SPARKs only send status frames while they get a heartbeat, so
      // keep it alive, but hold every motor at zero output.
      if (send_rev_heartbeat_) {
        bus_->send_rev_heartbeat();
      }
      if (send_universal_heartbeat_) {
        bus_->send_universal_heartbeat();
      }
      for (const auto & j : joints_) {
        bus_->send_duty_cycle(j.can_id, 0.0f);
      }
      warned = false;
    } else if (since_write < command_watchdog_s_) {
      if (send_rev_heartbeat_) {
        bus_->send_rev_heartbeat();
      }
      if (send_universal_heartbeat_) {
        bus_->send_universal_heartbeat();
      }
      warned = false;
    } else if (!warned) {
      RCLCPP_ERROR(
        logger_, "write() not called for %.2f s -> heartbeat withheld, SPARKs will disable",
        since_write);
      warned = true;
    }
    std::this_thread::sleep_until(next);
  }
}

// --------------------------------------------------------------------------
// read / write
// --------------------------------------------------------------------------
void SparkMaxSwerveSystem::update_joint_state(SparkJoint & j, const SparkFeedback & fb)
{
  const double motor_rot = fb.motor_position / motor_units_per_rev_;
  const double motor_rpm = fb.motor_velocity / motor_units_per_rpm_;
  j.motor_position_raw = fb.motor_position;

  if (j.is_steer) {
    const double seed_rot = j.seed_motor_rot / motor_units_per_rev_;
    j.position = j.seed_angle + j.direction * (motor_rot - seed_rot) / steer_gear_ratio_ * kTwoPi;
    j.velocity = j.direction * motor_rpm / steer_gear_ratio_ * kTwoPi / 60.0;
  } else {
    j.position = j.direction * motor_rot / drive_gear_ratio_ * kTwoPi;
    j.velocity = j.direction * motor_rpm / drive_gear_ratio_ * kTwoPi / 60.0;
  }
}

hardware_interface::return_type SparkMaxSwerveSystem::read(
  const rclcpp::Time &, const rclcpp::Duration &)
{
  if (!bus_) {
    return hardware_interface::return_type::ERROR;
  }
  for (auto & j : joints_) {
    const auto fb = bus_->feedback(j.can_id);
    const double age = std::max(age_s(fb.last_position), age_s(fb.last_velocity));
    if (active_ && age > feedback_timeout_s_) {
      RCLCPP_ERROR(
        logger_, "%s (CAN id %d): no encoder feedback for %.2f s -> hardware ERROR",
        j.name.c_str(), j.can_id, age);
      active_ = false;
      stop_all_motors();
      return hardware_interface::return_type::ERROR;
    }
    update_joint_state(j, fb);
  }
  return hardware_interface::return_type::OK;
}

hardware_interface::return_type SparkMaxSwerveSystem::write(
  const rclcpp::Time &, const rclcpp::Duration &)
{
  if (!bus_) {
    return hardware_interface::return_type::ERROR;
  }
  last_write_ns_ = steady_now_ns();
  if (!active_) {
    return hardware_interface::return_type::OK;
  }

  for (auto & j : joints_) {
    const bool valid = std::isfinite(j.command);

    if (j.is_steer) {
      if (!valid) {
        bus_->send_duty_cycle(j.can_id, 0.0f);
        continue;
      }
      // Shortest way to the commanded angle (commands may be unwrapped).
      const double err = wrap_pi(j.command - j.position);

      if (steer_mode_ == SteerControlMode::kSoftware) {
        double duty = 0.0;
        if (std::fabs(err) > steer_deadband_rad_) {
          duty = steer_kp_ * err - steer_kd_ * j.velocity + std::copysign(steer_ks_, err);
          duty = std::clamp(duty, -steer_max_duty_, steer_max_duty_);
        }
        bus_->send_duty_cycle(j.can_id, static_cast<float>(j.direction * duty));
      } else {
        // SPARK position PID on its primary encoder: target relative to now,
        // so no wrapping issues on the device.
        const double delta_motor_units =
          j.direction * err / kTwoPi * steer_gear_ratio_ * motor_units_per_rev_;
        bus_->send_position(
          j.can_id, static_cast<float>(j.motor_position_raw + delta_motor_units));
      }
    } else {
      const double cmd = valid ? j.command : 0.0;
      if (drive_mode_ == DriveControlMode::kDutyCycle) {
        double duty = 0.0;
        if (std::fabs(cmd) > 1e-3) {
          duty = drive_kff_ * cmd + drive_kp_ * (cmd - j.velocity);
          duty = std::clamp(duty, -drive_max_duty_, drive_max_duty_);
        }
        bus_->send_duty_cycle(j.can_id, static_cast<float>(j.direction * duty));
      } else {
        const double motor_rpm = j.direction * cmd * drive_gear_ratio_ * 60.0 / kTwoPi;
        bus_->send_velocity(j.can_id, static_cast<float>(motor_rpm * motor_units_per_rpm_));
      }
    }
  }
  return hardware_interface::return_type::OK;
}

}  // namespace charlotte_hardware

PLUGINLIB_EXPORT_CLASS(
  charlotte_hardware::SparkMaxSwerveSystem, hardware_interface::SystemInterface)
