// spark_max_can.hpp
//
// Minimal SocketCAN driver for REV SPARK MAX motor controllers, used without a
// roboRIO. It covers only what a swerve drive needs:
//   * heartbeat (REV "non-roboRIO" heartbeat and/or the FRC universal heartbeat)
//   * duty-cycle / velocity / position setpoints
//   * decoding of the periodic status frames with encoder data
//
// CAN arbitration ID layout (FRC CAN spec, 29-bit extended):
//   [28:24] device type (2 = motor controller)
//   [23:16] manufacturer (5 = REV)
//   [15:10] API class
//   [ 9: 6] API index
//   [ 5: 0] device (CAN) id
//
// SPARK firmware 25.x reorganised the status frames. Both layouts are supported:
// SPARKs on firmware 25+/26 only send status frames while they receive a
// heartbeat, so the heartbeat must run before any feedback can be read.
//
//   2025 layout: Status 2 = primary encoder velocity [0:4] + position [4:8]
//                Status 5 = duty-cycle (absolute) encoder velocity [0:4] + position [4:8]
//   2024 layout: Status 1 = velocity [0:4] (+ temp/voltage/current)
//                Status 2 = position [0:4]
//                Status 5 = absolute encoder position [0:4]
// Use charlotte_hardware/scripts/spark_can_probe.py to check which one your
// controllers send before driving the robot.

#ifndef CHARLOTTE_HARDWARE__SPARK_MAX_CAN_HPP_
#define CHARLOTTE_HARDWARE__SPARK_MAX_CAN_HPP_

#include <linux/can.h>

#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <mutex>
#include <string>
#include <thread>

namespace charlotte_hardware
{

enum class StatusLayout
{
  kFirmware2024,
  kFirmware2025,
};

// Arbitration-ID building blocks
constexpr uint32_t kRevMotorControllerBase = (2u << 24) | (5u << 16);  // 0x02050000
constexpr uint32_t api(uint32_t api_class, uint32_t api_index)
{
  return (api_class << 10) | (api_index << 6);
}

constexpr uint32_t kApiDutyCycleSetpoint = api(0, 2);   // 0x0080  -> 0x2050080 + id
constexpr uint32_t kApiVelocitySetpoint = api(1, 2);    // 0x0480  -> 0x2050480 + id
constexpr uint32_t kApiPositionSetpoint = api(3, 2);    // 0x0C80  -> 0x2050C80 + id
// Periodic status frames. Older firmware sends them in API class 6
// (0x020518xx); firmware 26.x was measured sending them in API class 46
// (0x0205B8xx). Both are accepted; only the API *index* (0..9) matters.
constexpr uint32_t kStatusClassLegacy = 6;
constexpr uint32_t kStatusClassNew = 46;
constexpr uint32_t kStatusIndex0 = 0;
constexpr uint32_t kStatusIndex1 = 1;
constexpr uint32_t kStatusIndex2 = 2;
constexpr uint32_t kStatusIndex5 = 5;
constexpr uint32_t kApiStatus0 = api(kStatusClassNew, 0);   // 0xB800
constexpr uint32_t kApiStatus1 = api(kStatusClassNew, 1);   // 0xB840
constexpr uint32_t kApiStatus2 = api(kStatusClassNew, 2);   // 0xB880
constexpr uint32_t kApiStatus5 = api(kStatusClassNew, 5);   // 0xB940

// REV non-roboRIO heartbeat, 8 bytes, bit n = "device n enabled"
constexpr uint32_t kRevHeartbeatId = kRevMotorControllerBase | api(11, 2);  // 0x2052C80
// FRC universal heartbeat (normally sent by the roboRIO every 20 ms)
constexpr uint32_t kUniversalHeartbeatId = 0x01011840;

using SteadyClock = std::chrono::steady_clock;

struct SparkFeedback
{
  // Primary (built-in NEO / NEO 550) encoder, native units unless the SPARK
  // has a conversion factor configured: rotations and RPM.
  double motor_position{0.0};
  double motor_velocity{0.0};
  // Duty-cycle absolute encoder on the data port (MAXSwerve Through Bore).
  // Native units: rotations (0..1) and RPM.
  double abs_position{0.0};
  double abs_velocity{0.0};

  bool has_position{false};
  bool has_velocity{false};
  bool has_abs{false};
  SteadyClock::time_point last_position{};
  SteadyClock::time_point last_velocity{};
  SteadyClock::time_point last_abs{};
  uint64_t frames_received{0};
};

class SparkMaxCanBus
{
public:
  explicit SparkMaxCanBus(StatusLayout layout);
  ~SparkMaxCanBus();

  SparkMaxCanBus(const SparkMaxCanBus &) = delete;
  SparkMaxCanBus & operator=(const SparkMaxCanBus &) = delete;

  // Opens and binds the SocketCAN interface (e.g. "can0") and starts the RX thread.
  bool open(const std::string & interface_name, std::string & error);
  void close();
  bool is_open() const {return sock_ >= 0;}

  // Thread-safe copy of the latest feedback of a device (0..62).
  SparkFeedback feedback(uint8_t device_id) const;

  bool send_duty_cycle(uint8_t device_id, float duty);       // -1 .. 1
  bool send_velocity(uint8_t device_id, float velocity);     // RPM (or converted units)
  bool send_position(uint8_t device_id, float position);     // rotations (or converted units)
  bool send_rev_heartbeat();
  bool send_universal_heartbeat();

  uint64_t tx_errors() const {return tx_errors_.load();}
  uint64_t rx_frames() const {return rx_frames_.load();}

private:
  bool send_setpoint(uint32_t api_id, uint8_t device_id, float value);
  bool send_frame(uint32_t arbitration_id, const uint8_t * data, uint8_t len);
  void rx_loop();
  void handle_frame(const struct can_frame & frame);

  StatusLayout layout_;
  int sock_{-1};
  std::thread rx_thread_;
  std::atomic<bool> running_{false};
  mutable std::mutex mutex_;
  std::array<SparkFeedback, 64> feedback_{};
  std::atomic<uint64_t> tx_errors_{0};
  std::atomic<uint64_t> rx_frames_{0};
};

}  // namespace charlotte_hardware

#endif  // CHARLOTTE_HARDWARE__SPARK_MAX_CAN_HPP_
