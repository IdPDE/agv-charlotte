// spark_max_swerve_system.hpp
//
// ros2_control SystemInterface for a swerve robot with REV MAXSwerve modules
// (NEO drive + NEO 550 steering, each on a SPARK MAX on a SocketCAN bus).
//
// Every <joint> in the <ros2_control> block is one SPARK MAX:
//   * a joint with a "position" command interface is a STEERING joint
//   * a joint with a "velocity" command interface is a DRIVE (wheel) joint
//
// Units towards ros2_control (what ffw_swerve_drive_controller expects):
//   steering: position [rad] (continuous, not wrapped), velocity [rad/s]
//   wheel:    position [rad], velocity [rad/s]

#ifndef CHARLOTTE_HARDWARE__SPARK_MAX_SWERVE_SYSTEM_HPP_
#define CHARLOTTE_HARDWARE__SPARK_MAX_SWERVE_SYSTEM_HPP_

#include <atomic>
#include <chrono>
#include <memory>
#include <string>
#include <thread>
#include <vector>

#include "charlotte_hardware/spark_max_can.hpp"
#include "hardware_interface/handle.hpp"
#include "hardware_interface/hardware_info.hpp"
#include "hardware_interface/system_interface.hpp"
#include "hardware_interface/types/hardware_interface_return_values.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_lifecycle/state.hpp"

namespace charlotte_hardware
{

enum class SteerControlMode {kSoftware, kOnboardPosition};
enum class DriveControlMode {kDutyCycle, kVelocity};

struct SparkJoint
{
  std::string name;
  bool is_steer{false};
  uint8_t can_id{0};
  double direction{1.0};   // +1 / -1: flips motor + encoder sign for this joint
  double offset{0.0};      // steering only: absolute-encoder angle [rad] that means "straight ahead"
  double abs_sign{1.0};    // steering only: sign of the absolute encoder vs. joint (+CCW)

  // ros2_control buffers
  double position{0.0};
  double velocity{0.0};
  double command{0.0};

  // steering: relative-encoder angle = seed_angle + (motor_rot - seed_motor_rot) * k
  double seed_angle{0.0};
  double seed_motor_rot{0.0};
  double motor_position_raw{0.0};  // last primary-encoder reading (device units)
};

class SparkMaxSwerveSystem : public hardware_interface::SystemInterface
{
public:
  RCLCPP_SHARED_PTR_DEFINITIONS(SparkMaxSwerveSystem)

  ~SparkMaxSwerveSystem() override;

  hardware_interface::CallbackReturn on_init(
    const hardware_interface::HardwareInfo & info) override;
  hardware_interface::CallbackReturn on_configure(
    const rclcpp_lifecycle::State & previous_state) override;
  hardware_interface::CallbackReturn on_cleanup(
    const rclcpp_lifecycle::State & previous_state) override;
  hardware_interface::CallbackReturn on_activate(
    const rclcpp_lifecycle::State & previous_state) override;
  hardware_interface::CallbackReturn on_deactivate(
    const rclcpp_lifecycle::State & previous_state) override;
  hardware_interface::CallbackReturn on_shutdown(
    const rclcpp_lifecycle::State & previous_state) override;
  hardware_interface::CallbackReturn on_error(
    const rclcpp_lifecycle::State & previous_state) override;

  std::vector<hardware_interface::StateInterface> export_state_interfaces() override;
  std::vector<hardware_interface::CommandInterface> export_command_interfaces() override;

  hardware_interface::return_type read(
    const rclcpp::Time & time, const rclcpp::Duration & period) override;
  hardware_interface::return_type write(
    const rclcpp::Time & time, const rclcpp::Duration & period) override;

private:
  void heartbeat_loop();
  void stop_all_motors();
  void stop_heartbeat_thread();
  void update_joint_state(SparkJoint & joint, const SparkFeedback & fb);
  bool wait_for_feedback(double timeout_s);
  void seed_steering(SparkJoint & joint, const SparkFeedback & fb, bool use_abs);

  rclcpp::Logger logger_{rclcpp::get_logger("SparkMaxSwerveSystem")};
  rclcpp::Clock steady_clock_{RCL_STEADY_TIME};

  // ---- parameters (see URDF <hardware> params) ----
  std::string can_interface_{"can0"};
  StatusLayout layout_{StatusLayout::kFirmware2025};
  bool send_rev_heartbeat_{true};
  bool send_universal_heartbeat_{false};  // blocks firmware 26.x, see .cpp
  int heartbeat_period_ms_{20};
  double command_watchdog_s_{0.15};
  double feedback_timeout_s_{0.3};
  double startup_timeout_s_{5.0};
  bool require_absolute_encoder_{true};

  double steer_gear_ratio_{9424.0 / 203.0};  // MAXSwerve steering, 46.42:1
  double drive_gear_ratio_{5.5};             // MAXSwerve 12T pinion
  double abs_units_per_rev_{1.0};            // absolute-encoder native units per module rev
  double motor_units_per_rev_{1.0};          // primary-encoder position units per motor rev
  double motor_units_per_rpm_{1.0};          // primary-encoder velocity units per motor RPM

  SteerControlMode steer_mode_{SteerControlMode::kSoftware};
  double steer_kp_{1.0};          // duty per rad
  double steer_kd_{0.02};         // duty per rad/s
  double steer_ks_{0.02};         // static-friction duty
  double steer_max_duty_{0.6};
  double steer_deadband_rad_{0.015};

  DriveControlMode drive_mode_{DriveControlMode::kDutyCycle};
  double drive_free_speed_rpm_{5676.0};  // NEO
  double drive_kff_{0.0};                // duty per wheel rad/s (computed if 0)
  double drive_kp_{0.002};               // duty per wheel rad/s error
  double drive_max_duty_{0.8};

  // ---- runtime ----
  std::vector<SparkJoint> joints_;
  std::unique_ptr<SparkMaxCanBus> bus_;
  std::thread heartbeat_thread_;
  std::atomic<bool> heartbeat_running_{false};
  std::atomic<bool> active_{false};
  std::atomic<int64_t> last_write_ns_{0};
  SteadyClock::time_point stale_since_{};
  bool stale_{false};
};

}  // namespace charlotte_hardware

#endif  // CHARLOTTE_HARDWARE__SPARK_MAX_SWERVE_SYSTEM_HPP_
