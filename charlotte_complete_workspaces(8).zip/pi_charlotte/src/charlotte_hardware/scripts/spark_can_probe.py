#!/usr/bin/env python3
"""
spark_can_probe.py - bring-up / calibration tool for the SPARK MAXes on can0.

Run this on the Pi BEFORE starting ros2_control, and never at the same time
(only one program may send the heartbeat / setpoints).

  # 1. What is on the bus? Which status frames, which layout?
  ros2 run charlotte_hardware spark_can_probe.py monitor

  # 2. Steering offsets: point all wheels straight ahead (use the REV alignment
  #    tool / a straight edge; all bevel gears facing the same side), then:
  ros2 run charlotte_hardware spark_can_probe.py calibrate --steer-ids 12 22 32 42

  # 3. Direction check, ROBOT ON BLOCKS (wheels off the ground):
  ros2 run charlotte_hardware spark_can_probe.py spin --id 11 --duty 0.05
  ros2 run charlotte_hardware spark_can_probe.py spin --id 12 --duty 0.05

Needs: sudo apt install python3-can
"""

import argparse
import math
import struct
import sys
import time

try:
    import can
except ImportError:
    sys.exit('python-can missing: sudo apt install python3-can')

REV_BASE = (2 << 24) | (5 << 16)            # motor controller, REV
# Status frames: API class 6 on older firmware, class 46 on firmware 26.x
# (measured on Charlotte: 0x0205B8xx). Both accepted.
STATUS_CLASSES = (6, 46)
API_DUTY = (0 << 10) | (2 << 6)             # 0x2050080 + id
REV_HEARTBEAT = REV_BASE | (11 << 10) | (2 << 6)  # 0x2052C80
UNIVERSAL_HEARTBEAT = 0x01011840


def f32(data, offset):
    return struct.unpack_from('<f', bytes(data), offset)[0]


def split_id(arb):
    return {
        'device': arb & 0x3F,
        'api_index': (arb >> 6) & 0xF,
        'api_class': (arb >> 10) & 0x3F,
        'rev': (arb & 0x1FFF0000) == REV_BASE,
    }


def decode(layout, status, data):
    """Return dict of decoded values for one status frame."""
    out = {}
    if layout == '2025':
        if status == 2 and len(data) >= 8:
            out['motor_vel_rpm'] = f32(data, 0)
            out['motor_pos_rot'] = f32(data, 4)
        elif status == 5 and len(data) >= 8:
            out['abs_vel_rpm'] = f32(data, 0)
            out['abs_pos'] = f32(data, 4)
    else:
        if status == 1 and len(data) >= 4:
            out['motor_vel_rpm'] = f32(data, 0)
        elif status == 2 and len(data) >= 4:
            out['motor_pos_rot'] = f32(data, 0)
        elif status == 5 and len(data) >= 4:
            out['abs_pos'] = f32(data, 0)
    return out


def is_status(p):
    return p['rev'] and p['api_class'] in STATUS_CLASSES


class KeepAlive:
    """SPARKs (firmware 25+/26) only send status frames while they receive a
    heartbeat. Send heartbeat + ZERO duty to every device seen, every 20 ms."""

    def __init__(self, bus, ids=()):
        self.bus = bus
        self.ids = set(ids)
        self.next = 0.0

    def tick(self):
        now = time.time()
        if now < self.next:
            return
        self.next = now + 0.02
        send_heartbeats(self.bus)
        for dev in self.ids:
            send_duty(self.bus, dev, 0.0)

    def stop(self):
        for _ in range(3):
            for dev in self.ids:
                send_duty(self.bus, dev, 0.0)
            time.sleep(0.01)


def open_bus(channel):
    try:
        return can.interface.Bus(interface='socketcan', channel=channel)
    except Exception as e:  # noqa: BLE001
        sys.exit(f'Cannot open {channel}: {e}\n'
                 f'Bring it up: sudo ip link set {channel} up type can bitrate 1000000')


def send_heartbeats(bus):
    # Only the REV heartbeat. The FRC universal heartbeat (0x01011840) keeps
    # firmware 26.1.5 SPARKs disabled (measured on Charlotte), so never send it.
    bus.send(can.Message(arbitration_id=REV_HEARTBEAT, data=[0xFF] * 8, is_extended_id=True))


def send_duty(bus, dev, duty):
    data = struct.pack('<f', duty) + bytes(4)
    bus.send(can.Message(arbitration_id=REV_BASE | API_DUTY | dev, data=data, is_extended_id=True))


# ---------------------------------------------------------------- monitor
def cmd_monitor(args):
    bus = open_bus(args.channel)
    stats = {}   # (dev, status) -> [count, last_data]
    keep = KeepAlive(bus)
    print(f'Listening on {args.channel} for {args.seconds:.0f} s '
          '(sending heartbeat + zero output, motors stay still) ...')
    # short warm-up so counting starts with frames flowing
    t_warm = time.time()
    while time.time() - t_warm < 0.5:
        keep.tick()
        msg = bus.recv(timeout=0.005)
        if msg is not None and msg.is_extended_id:
            p = split_id(msg.arbitration_id)
            if is_status(p):
                keep.ids.add(p['device'])
    t0 = time.time()
    try:
        while time.time() - t0 < args.seconds:
            keep.tick()
            msg = bus.recv(timeout=0.005)
            if msg is None or not msg.is_extended_id:
                continue
            p = split_id(msg.arbitration_id)
            if not is_status(p):
                continue
            keep.ids.add(p['device'])
            key = (p['device'], p['api_index'])
            s = stats.setdefault(key, [0, None])
            s[0] += 1
            s[1] = msg.data
    finally:
        keep.stop()
        bus.shutdown()
    dt = time.time() - t0

    if not stats:
        print('\nNO REV status frames received. Check wiring, 120 ohm termination, '
              'bitrate (1 Mbit/s), power to the SPARKs, and `candump can0`.')
        return

    devices = sorted({d for d, _ in stats})
    print(f'\nFound {len(devices)} SPARK device id(s): {devices}\n')
    for d in devices:
        print(f'device {d}:')
        for (dev, st), (n, data) in sorted(stats.items()):
            if dev != d:
                continue
            vals = decode(args.layout, st, data)
            vtxt = ', '.join(f'{k}={v:.4f}' for k, v in vals.items())
            print(f'   status {st}: {n / dt:6.1f} Hz   raw={bytes(data).hex()}   {vtxt}')
    print('\nInterpretation hints:')
    print('  * 2025 firmware sends motor velocity AND position in status 2 (bytes 0-3 / 4-7).')
    print('    2024 firmware sends velocity in status 1 and position in status 2 (bytes 0-3).')
    print('    Turn a wheel by hand while monitoring: the value that accumulates is the position.')
    print('  * Steering SPARKs must show status 5 (absolute encoder), value 0..1 rotations.')
    print('  * Status 2 should be ~50 Hz. If missing/slow, enable it in the REV Hardware Client.')


# -------------------------------------------------------------- calibrate
def cmd_calibrate(args):
    bus = open_bus(args.channel)
    samples = {i: [] for i in args.steer_ids}
    keep = KeepAlive(bus, args.steer_ids)
    t0 = time.time()
    try:
        while time.time() - t0 < args.seconds:
            keep.tick()
            msg = bus.recv(timeout=0.005)
            if msg is None or not msg.is_extended_id:
                continue
            p = split_id(msg.arbitration_id)
            if is_status(p) and p['api_index'] == 5 and p['device'] in samples:
                vals = decode(args.layout, 5, msg.data)
                if 'abs_pos' in vals:
                    samples[p['device']].append(vals['abs_pos'])
    finally:
        keep.stop()
        bus.shutdown()

    print('\nWith all wheels pointing straight ahead, put these in the URDF '
          '(<param name="offset"> of each steering joint):\n')
    for dev, s in samples.items():
        if not s:
            print(f'  id {dev}: NO absolute encoder frames (status 5) received!')
            continue
        # circular mean
        ang = [args.abs_sign * v / args.abs_units_per_rev * 2 * math.pi for v in s]
        mean = math.atan2(sum(math.sin(a) for a in ang), sum(math.cos(a) for a in ang))
        spread = max(abs(math.remainder(a - mean, 2 * math.pi)) for a in ang)
        print(f'  id {dev}: offset = {mean:+.4f} rad   ({len(s)} samples, '
              f'spread {math.degrees(spread):.2f} deg)')


# ------------------------------------------------------------------- spin
def cmd_spin(args):
    if abs(args.duty) > 0.3:
        sys.exit('Refusing |duty| > 0.3 in a test.')
    print(f'Spinning device {args.id} at duty {args.duty} for {args.seconds} s. '
          'ROBOT MUST BE ON BLOCKS. Ctrl+C to stop.')
    bus = open_bus(args.channel)
    t0 = time.time()
    start = {}
    last = {}
    try:
        while time.time() - t0 < args.seconds:
            send_heartbeats(bus)
            send_duty(bus, args.id, args.duty)
            t_loop = time.time()
            while time.time() - t_loop < 0.02:
                msg = bus.recv(timeout=0.005)
                if msg is None or not msg.is_extended_id:
                    continue
                p = split_id(msg.arbitration_id)
                if is_status(p) and p['device'] == args.id:
                    vals = decode(args.layout, p['api_index'], msg.data)
                    for k, v in vals.items():
                        start.setdefault(k, v)
                        last[k] = v
    except KeyboardInterrupt:
        pass
    finally:
        for _ in range(5):
            send_duty(bus, args.id, 0.0)
            time.sleep(0.01)
        bus.shutdown()

    print('\nResult:')
    for k in last:
        print(f'  {k}: start={start[k]:.4f} end={last[k]:.4f} delta={last[k] - start[k]:+.4f}')
    print('\nExpected for POSITIVE duty with direction=+1 in the URDF:')
    print('  drive SPARK: wheel rolls so the robot would move FORWARD (+x)')
    print('  steer SPARK: module turns COUNTER-CLOCKWISE seen from above')
    print('  and the motor position should INCREASE (otherwise the decoding is wrong).')
    print('If the physical motion is the other way, set direction=-1 for that joint.')
    print('For steering: if abs_pos moves opposite to the turning direction you expect,')
    print('set abs_sign=-1 (or invert the absolute encoder in the REV Hardware Client).')


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--channel', default='can0')
    ap.add_argument('--layout', choices=['2024', '2025'], default='2025',
                    help='SPARK firmware status-frame layout (default 2025)')
    sub = ap.add_subparsers(dest='cmd', required=True)

    m = sub.add_parser('monitor')
    m.add_argument('--seconds', type=float, default=3.0)

    c = sub.add_parser('calibrate')
    c.add_argument('--steer-ids', type=int, nargs='+', default=[12, 22, 32, 42])
    c.add_argument('--seconds', type=float, default=2.0)
    c.add_argument('--abs-sign', type=float, default=1.0)
    c.add_argument('--abs-units-per-rev', type=float, default=1.0)

    s = sub.add_parser('spin')
    s.add_argument('--id', type=int, required=True)
    s.add_argument('--duty', type=float, default=0.05)
    s.add_argument('--seconds', type=float, default=2.0)

    args = ap.parse_args()
    {'monitor': cmd_monitor, 'calibrate': cmd_calibrate, 'spin': cmd_spin}[args.cmd](args)


if __name__ == '__main__':
    main()
