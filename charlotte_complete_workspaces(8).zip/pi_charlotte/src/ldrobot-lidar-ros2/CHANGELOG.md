CHANGELOG
=========

2026-05-17
----------

- Replace vendored `ldlidar_driver` folder with the official [ldlidar_stl_sdk](https://github.com/ldrobotSensorTeam/ldlidar_stl_sdk) git submodule

  - Clone with `git clone --recurse-submodules` or run `git submodule update --init --recursive` after cloning
- Improve the SLAM demo launch file to fully leverage lifecycle and composition:

  - slam_toolbox lifecycle node is controlled by the same lifecycle manager as ldlidar_node
  - slam_toolbox is loaded as component in the same container as ldlidar_node to leverage IPC and zero-copy on laser scan data

2025-02-16
----------

- Improve 'ldlidar_bringup.launch.py'
  - Add 'container_name' argument to load the LDLidar component into an existing container. If left empty the launch file creates a new container

2025-02-01
----------

- Add Jazzy support

2024-11-25
----------

- Remove LDLidar executable node
- Rename `ldlidar.launch.py` to `ldlidar_bringup.launch.py`
- `ldlidar_bringup.launch.py` starts the node as a component in a `component_container_isolated` (`component_container` in Foxy for compatibility)

2024-02-08
----------

- Add `lidar.bins` parameter to set a fixed scan bin size for improved compatibility with the SLAM Toolbox package
- Add parameter `comm.timeout_msec` 
- Change `lidar.rot_verse` parameter from integer to string
- Change `lidar.units` parameter from integer to string
- Add new `ldlidar_slam.launch.py` launch file as a demo for SLAM Toolbox integration
- Add new `slam_toolbox.yaml` parameter file for SLAM Toolbox
- Add parameters `lidar.range_min` and `lidar.range_max`
- Add parameters `lidar.enable_angle_crop`,`lidar.angle_crop_min`, and `lidar.angle_crop_max`

2024-02-03
----------

- Add support for QoS override parameters -> https://design.ros2.org/articles/qos_configurability.html#adding-a-new-mechanism-vs-using-parameters

2022-11-27
----------

- Add direct serial port connection feature

v0.2.0 - Humble
---------------

- Change license from MIT to Apache-2.0
- Code refactoring to meet [ROS2 rules](https://docs.ros.org/en/humble/The-ROS2-Project/Contributing/Code-Style-Language-Versions.html)
- Add CONTRIBUTING.md
- Add udev rules and install scripts
- Fix issue with Rviz2 config files
- Fix `nav2_lifecycle_manager` interaction in ROS2 Humble
  - Derive `ldlidar::LdLidarComponent` from `nav2_util::LifecycleNode` instead of `rclcpp::LifecycleNode` 
- Improve parameter handling
- Set default QoS to `rclcpp::SensorDataQoS`

v0.1.0
------

- ROS2 Foxy and Ubuntu 20.04
- First working version of the node based on ROS2 lifecycle architecture
- Python launch scripts
- Parameters customization
- Examples
