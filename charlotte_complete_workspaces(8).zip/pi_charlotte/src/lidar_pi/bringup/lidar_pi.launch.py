# lidar_pi.launch.py
#
# Runs on the RASPBERRY PI (lidar plugged in via USB).
# Starts the LD lidar driver with the parameters in lidar_pi/config/ldlidar.yaml
# and a lifecycle manager that configures + activates it automatically.
#
# Publishes ONLY sensor data: sensor_msgs/LaserScan on <scan_topic>
# (default /ldlidar_node/scan, frame_id from <frame_id>, default ldlidar_link).
# No robot_description / TF is published here; that comes from the laptop.
#
# For the real robot, charlotte_pi_bringup/robot_pi.launch.py includes this
# file with scan_topic:=/charlotte/scan_raw frame_id:=lidar_link so the data
# matches the URDF and the laptop's scan_mask_node (same as in Gazebo).
#
# ROS_DOMAIN_ID is taken from the environment (~/.bashrc: export ROS_DOMAIN_ID=4).
#
#   ros2 launch lidar_pi lidar_pi.launch.py

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import ComposableNodeContainer, Node
from launch_ros.descriptions import ComposableNode


def generate_launch_description():
    pkg_share = get_package_share_directory('lidar_pi')

    lidar_params = LaunchConfiguration('lidar_params')
    scan_topic = LaunchConfiguration('scan_topic')
    frame_id = LaunchConfiguration('frame_id')
    lc_mgr_params = os.path.join(pkg_share, 'config', 'lifecycle_mgr.yaml')

    domain_id = os.environ.get('ROS_DOMAIN_ID', '0 (not set!)')

    # Container holding the lidar driver component
    ldlidar_container = ComposableNodeContainer(
        name='ldlidar_container',
        namespace='',
        package='rclcpp_components',
        executable='component_container_isolated',
        output='screen',
        composable_node_descriptions=[
            ComposableNode(
                package='ldlidar_component',
                plugin='ldlidar::LdLidarComponent',
                name='ldlidar_node',
                namespace='',
                parameters=[lidar_params, {'lidar.frame_id': frame_id}],
                remappings=[('/ldlidar_node/scan', scan_topic)],
                extra_arguments=[{'use_intra_process_comms': True}],
            ),
        ],
    )

    # Configures and activates ldlidar_node (it is a lifecycle node)
    lc_mgr_node = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager',
        output='screen',
        parameters=[lc_mgr_params],
    )

    return LaunchDescription([
        SetEnvironmentVariable('RCUTILS_COLORIZED_OUTPUT', '1'),

        DeclareLaunchArgument(
            'lidar_params',
            default_value=os.path.join(pkg_share, 'config', 'ldlidar.yaml'),
            description='Full path to the ldlidar parameter file'),

        DeclareLaunchArgument(
            'scan_topic', default_value='/ldlidar_node/scan',
            description='Topic the LaserScan is published on'),

        DeclareLaunchArgument(
            'frame_id', default_value='ldlidar_link',
            description='frame_id of the LaserScan (lidar_link for the robot URDF)'),

        LogInfo(msg=f'[lidar_pi] ROS_DOMAIN_ID={domain_id}'),

        ldlidar_container,
        lc_mgr_node,
    ])
