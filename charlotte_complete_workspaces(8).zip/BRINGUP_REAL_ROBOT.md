# Charlotte – real robot bring-up

## What runs where
- **Pi** (`pi_charlotte`): `ros2_control_node` (/charlotte/controller_manager) with
  `charlotte_hardware/SparkMaxSwerveSystem` (SPARK MAX over can0), the swerve controller +
  joint_state_broadcaster (loaded there), and the LD19 lidar -> `/charlotte/scan_raw` (frame `lidar_link`).
- **Laptop** (`laptop_charlotte`): robot_state_publisher (publishes `/charlotte/robot_description`,
  which the Pi's controller_manager uses), spawners, scan mask, EKF, Nav2 / slam_toolbox, RViz.

## Files
Copy the folders over your workspaces (they only contain new/changed files):
- `pi_charlotte/src/charlotte_hardware` (new), `charlotte_pi_bringup` (new),
  `ffw_swerve_drive_controller` (copy of the laptop package), `lidar_pi/bringup/lidar_pi.launch.py` (changed)
- `laptop_charlotte/src/swerve_robot/description/charlotte_swerve_bot.urdf`, `bringup/robot_v2.launch.py`,
  `config/charlotte_slam_toolbox.yaml`, `package.xml` (changed/new)

`heartbeat.py`, `motor_control.py`, `hardware_agv.cpp` are replaced – never run them at the same time.

## One-time setup
Pi:
```bash
sudo apt install ros-jazzy-ros2-control ros-jazzy-ros2-controllers ros-jazzy-backward-ros \
  ros-jazzy-generate-parameter-library can-utils python3-can chrony
cd ~/pi_charlotte && colcon build --parallel-workers 1 && source install/setup.bash
```
CAN HAT (Charlotte: Waveshare RS485 CAN HAT, MCP2515, 12 MHz) - in `/boot/firmware/config.txt` under `[all]`:
```
dtparam=spi=on
dtoverlay=mcp2515-can0,oscillator=12000000,interrupt=25,spimaxfrequency=2000000
```
Reboot. Bring can0 up automatically at boot (otherwise run `setup_can.sh` after every boot):
```bash
sudo tee /etc/systemd/network/80-can.network > /dev/null <<'EOT'
[Match]
Name=can0

[CAN]
BitRate=1M
RestartSec=100ms
EOT
sudo systemctl enable systemd-networkd && sudo systemctl restart systemd-networkd
```
CAN wiring: yellow = CAN-H, green = CAN-L (use the HAT's CAN H/L terminals, not RS485 A/B),
120 ohm at both ends (HAT jumper "120R" + one resistor at the last SPARK); ~60 ohm between H and L with power off.
Watch `ip -s link show can0` for overruns; MCP2515 HATs can drop frames at 1 Mbit/s with 8 SPARKs
(an MCP2518FD HAT or a gs_usb/CANable adapter is more robust).

Laptop: `sudo apt install ros-jazzy-slam-toolbox ros-jazzy-teleop-twist-keyboard chrony`, rebuild.

**Time sync is required** (TF/odom/scan stamps come from the Pi): run chrony on both, e.g. make the
laptop the server (`allow 192.168.1.0/24` in /etc/chrony/chrony.conf) and add
`server <laptop-ip> iburst` on the Pi. Check with `chronyc tracking` (offset should be a few ms).

Both: `export ROS_DOMAIN_ID=4`.

SPARK MAXes (REV Hardware Client, USB): CAN IDs 11/12, 21/22, 31/32, 41/42 (drive/steer for fl, fr, rl, rr –
or change the URDF), smart current limit ~20 A (NEO 550) / ~50 A (NEO), idle mode brake, save.
With the default `software` / `duty_cycle` modes no PID tuning in the SPARKs is needed.

## Bring-up (robot ON BLOCKS)
```bash
ros2 run charlotte_hardware spark_can_probe.py monitor
```
- 8 devices, status 2 at ~50 Hz, steering ids also status 5. Turn a wheel by hand: the accumulating
  value is position. If it's in bytes 0-3 of status 2 instead of 4-7 -> `--layout 2024` and set
  `firmware_layout` to `2024` in the URDF.
- No status 5? Enable the absolute-encoder signal in the Hardware Client, or set
  `require_absolute_encoder` false (then align wheels straight by hand before every start).

```bash
ros2 run charlotte_hardware spark_can_probe.py calibrate --steer-ids 12 22 32 42 --abs-sign -1
```
with all wheels straight ahead, bevel gears on the same side -> copy the offsets to the URDF.

```bash
ros2 run charlotte_hardware spark_can_probe.py spin --id 11 --duty 0.05   # each id
```
Positive duty must give: drive -> robot forward, steer -> CCW from above. Otherwise `direction=-1`.

## Measured on Charlotte (firmware 26.1.5)
- Status frames arrive in API class 46 (`0x0205B8xx`), layout 2025 (velocity bytes 0-3, position 4-7). Handled in code.
- SPARKs only send status frames while they receive the REV heartbeat (`0x02052C80`, 8 x 0xFF).
- The FRC universal heartbeat (`0x01011840`) keeps them DISABLED -> `send_universal_heartbeat` = false.
- Duty cycle frame `0x2050080 + id` (float32 LE + 4 zero bytes) works.
- URDF values: wheels `direction -1`; steering `direction 1`, `abs_sign -1`, offsets -0.0065 / -0.0126 / -0.0067 / -0.0125 (12/22/32/42); absolute encoders NOT inverted in the SPARKs.
- Motor 32: SPARK 32 had a config/firmware fault; fixed by re-flash + factory reset + reconfigure. Verified.

## Run
1. Pi: `ros2 launch charlotte_pi_bringup robot_pi.launch.py` (waits for the URDF)
2. Laptop, first test with teleop (no Nav2 needed):
   `ros2 launch swerve_robot robot_v2.launch.py use_sim_time:=false slam:=true`
   `ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args -r cmd_vel:=/charlotte/cmd_vel`
   Check in RViz: wheels steer correctly, lidar points match reality (else adjust `lidar_joint` yaw and
   the sectors in `scan_mask_swerve_drive.yaml`). Drive around slowly to build the map, then:
   `ros2 run nav2_map_server map_saver_cli -f ~/maps/lab --ros-args -r map:=/charlotte/map`
3. Navigate: `ros2 launch swerve_robot robot_v2.launch.py use_sim_time:=false map:=$HOME/maps/lab.yaml`
   -> "2D Pose Estimate" in RViz -> "Nav2 Goal".

Simulation still works as before: `ros2 launch swerve_robot robot_v2.launch.py` (sim_mode follows use_sim_time).

## Troubleshooting
- `No (complete) feedback from SPARK MAXes` -> run `monitor`; check wiring, termination, ids, layout.
- Spawners time out -> Pi launch not running / not discovered (`ros2 node list` on the laptop).
- TF extrapolation errors -> clock sync.
- Steering oscillates -> lower `steer_kp` or raise `steer_kd`; sluggish -> raise `steer_kp`/`steer_max_duty`.
- No real IMU: the EKF just uses wheel odometry (imu0 never arrives). Adding an IMU improves yaw.
